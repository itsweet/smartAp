# Please providing basic issue information

Issues may be answered much faster, if you provide more details ahead!

* branch your faced the issue. Currently 
   * 1.0 is the release, 
   * 1.1 is the master, 
   * and 2.0 is the development branch
* If you use a SNAPSHOT, ensure your updated to the latest. Please provide the
  commit your using
* If your issue is related to your own snippet, please provide that
* If you have logs, please provide them
* If you have tcpdump captures (wireshark), please provide them.

